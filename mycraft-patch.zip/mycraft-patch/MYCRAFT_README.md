# MyCraft Launcher (форк Fold Craft Launcher)

Android-лаунчер для Minecraft: Java Edition. Це форк
[Fold Craft Launcher](https://github.com/FCL-Team/FoldCraftLauncher) (FCL-Team),
який у свою чергу базується на HMCL та PojavLauncher.

## Ліцензія та авторство
Проєкт поширюється під **GNU GPL v3** (див. `LICENSE`). Тому:
- залиште файл `LICENSE` і згадку FCL-Team, HMCL, PojavLauncher та Boat;
- якщо роздаєте APK, надайте і вихідний код (з вашими змінами) під GPL-3.0.

## Що вже вміє (успадковано від FCL)
- Запуск Java Edition усіх версій: релізи, снапшоти, старі версії, Forge, Fabric, Quilt, NeoForge, OptiFine.
- Різні версії Java (8 / 17 / 21 тощо) та рендерери для мобільних GPU.
- **Власне керування**: редактор екранних кнопок і джойстика
  (код у `FCL/src/main/java/com/tungsten/fcl/control/`, дані кнопок у `control/data/`).
  Можна створювати групи кнопок, стилі кнопок і напрямків, швидкі текстові команди,
  зберігати та імпортувати схеми керування.
- Завантаження ігор, модпаків і модів (CurseForge, Modrinth), облікові записи.

## Що змінено у форку
- Назва застосунку: `MyCraft Launcher`.
- `applicationId`: `com.mycraft.launcher` (Java-пакети `com.tungsten.fcl` не чіпав, щоб нічого не зламати).
- Ключі підпису автора FCL видалено. Збірка за замовчуванням підписується debug-ключем;
  для свого релізного ключа покладіть `my-release.jks` поруч із `settings.gradle.kts`
  (alias `mycraft-key`) і задайте пароль у `FCL_KEYSTORE_PASSWORD` або `local.properties` (`pwd=...`).

## Збірка
1. Android Studio (свіжа) з Android SDK 35, NDK `27.0.12077973`, CMake, JDK 17.
2. Відкрийте папку проєкту, дочекайтесь Gradle sync.
3. (Необов'язково) у `local.properties`:
   ```
   curse.api.key=ВАШ_КЛЮЧ_CURSEFORGE
   arch=arm64        # збірка лише для arm64, швидше
   ```
4. Збірка: `./gradlew :FCL:assembleRelease` (або Build → Build APK у Studio).
   APK з'явиться у `FCL/build/outputs/apk/`.

> Збірка важка (нативний код, JRE-ресурси, перший sync може тривати довго) і потребує місця на диску.

## Де міняти керування
- Логіка кнопок: `control/data/ControlButtonData.java`, `ControlDirectionStyle.java`
- Діалоги редактора: `control/*Dialog.java`, `ui/controller/ControllerUI.java`
- Ігрове меню: `control/GameMenu.java`
