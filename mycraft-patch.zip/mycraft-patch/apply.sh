#!/usr/bin/env bash
# Usage: bash apply.sh   (run next to this folder)
set -e
git clone --depth 1 https://github.com/FCL-Team/FoldCraftLauncher.git MyCraftLauncher
cd MyCraftLauncher
git apply --whitespace=nowarn ../changes.patch
cp ../MYCRAFT_README.md .
rm -f key-store.jks private_key.pepk
echo "Done. Open the MyCraftLauncher folder in Android Studio."
